#include <jni.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#define GPIO_OUTPUT 0
#define GPIO_INPUT	1
#define GPIO_LOW	0
#define GPIO_HIGH	1

#define SYSFS_GPIO_DIR "/sys/class/gpio"

#define MAX_BUF 128
JNIEXPORT jint JNICALL Java_com_hbe_jnidriver_JNIDriver_gpioexport(JNIEnv * env, jobject obj, jint gpio){
	int fd, len;
	char buf[MAX_BUF];

	fd = open(SYSFS_GPIO_DIR "/export", O_WRONLY);

	if (fd < 0) {
		fprintf(stderr, "Can't export GPIO %d pin: %s\n", gpio, strerror(errno));
		return -1;
	}

	len = snprintf(buf, sizeof(buf), "%d", gpio);
	write(fd, buf, len);
	close(fd);

	return 0;
}

JNIEXPORT jint JNICALL Java_com_hbe_jnidriver_JNIDriver_gpiosetdir(JNIEnv * env, jobject obj,jint gpio){

	int fd, len;
	char buf[MAX_BUF];

	len = snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR  "/gpio%d/direction", gpio);

	fd = open(buf, O_WRONLY);

	if (fd < 0) {
		fprintf(stderr, "Can't set GPIO %d pin direction: %s\n", gpio, strerror(errno));
		return fd;
	}
	write(fd, "out", 4);

	close(fd);
	return 0;
}

JNIEXPORT jint JNICALL Java_com_hbe_jnidriver_JNIDriver_gpiosetval(JNIEnv * env, jobject obj, jint gpio, jint val){
	int fd, len;
	char buf[MAX_BUF];

	len = snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR "/gpio%d/value", gpio);
	fd = open(buf, O_WRONLY);

	if (fd < 0) {
		fprintf(stderr, "Can't set GPIO %d pin value: %s\n", gpio, strerror(errno));
		return fd;
	}
	if (val == GPIO_HIGH)
		write(fd, "1", 2);
	else
		write(fd, "0", 2);

	close(fd);
	return 0;
}

JNIEXPORT jint JNICALL Java_com_hbe_jnidriver_JNIDriver_gpiounexport(JNIEnv * env, jobject obj, jint gpio){
		int fd, len;
		char buf[MAX_BUF];
		fd = open(SYSFS_GPIO_DIR "/unexport", O_WRONLY);
		if (fd < 0) {
			fprintf(stderr, "Can't unexport GPIO %d pin: %s\n", gpio, strerror(errno));
			return fd;
		}
		len = snprintf(buf, sizeof(buf), "%d", gpio);
		write(fd, buf, len);
		close(fd);
	return 0;
}


jint gpio_set_val(jint gpio,jint val){
	int fd,len;
	char buf[MAX_BUF];

	len = snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR  "/gpio%d/value", gpio);

	fd = open(buf, O_WRONLY);

	if (fd < 0) {
		fprintf(stderr, "Can't set GPIO %d pin value: %s\n", gpio, strerror(errno));
		return fd;
	}

	if(val == GPIO_HIGH)
		write(fd,"1",2);
	else
		write(fd,"0",2);
	close(fd);
}


JNIEXPORT jint JNICALL Java_com_hbe_jnidriver_JNIDriver_gpiogomotor(JNIEnv * env, jobject obj){
	gpio_set_val(208,GPIO_LOW);
	usleep(10000);
	gpio_set_val(208,GPIO_HIGH);
	gpio_set_val(209,GPIO_LOW);
	usleep(10000);
	gpio_set_val(209,GPIO_HIGH);
	gpio_set_val(210,GPIO_LOW);
	usleep(10000);
	gpio_set_val(210,GPIO_HIGH);
	gpio_set_val(211,GPIO_LOW);
	usleep(10000);
	gpio_set_val(211,GPIO_HIGH);
	return 0;

}
JNIEXPORT jint JNICALL Java_com_hbe_jnidriver_JNIDriver_gpiostopmotor(JNIEnv * env, jobject obj){

	gpio_set_val(211,GPIO_LOW);

	gpio_set_val(210,GPIO_LOW);

	gpio_set_val(209,GPIO_LOW);

	gpio_set_val(208,GPIO_LOW);



	return 0;

}


