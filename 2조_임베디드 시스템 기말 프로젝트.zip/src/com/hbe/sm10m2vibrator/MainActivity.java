
package com.hbe.sm10m2vibrator;
//import android.os.Handler;
import java.util.Random;

import com.hbe.jnidriver.JNIDriver;
import com.hbe.sm10m2vibrator.R;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.Toast;
import android.widget.TextView;
import android.app.Activity;
import android.os.Message;
import android.widget.ToggleButton;
import android.os.CountDownTimer;
import java.util.*;
public class MainActivity extends Activity implements View.OnClickListener{
	ReceiveThread mSegThread;
	boolean mThreadRun = true;
	JNIDriver mDriver = new JNIDriver();
	
	TextView requestText, responseText;
	Button startBtn, answerBtn;
	Button[] buttons = new Button[10];
	int gpio =0, val =0;
	String answer ="";
	
	int randomNumber;
	
	int min = 1;
	int max =100;
	
	int count = 0;
	
	int direction =1;
	
	

	Scanner scanner = new Scanner (System.in);
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		Toast.makeText(MainActivity.this, "���� ��ư�� ���� ������ �������ּ���",Toast.LENGTH_SHORT).show();
		requestText = (TextView)findViewById(R.id.request_text);
		
		responseText = (TextView)findViewById(R.id.response_text);
		
		answerBtn = (Button)findViewById(R.id.answer_btn);
		
		startBtn = (Button)findViewById(R.id.start_btn);
		
		for(int i = 0; i<buttons.length; i++){
			String buttonID = "btn"+ i;
			int resourceID = getResources().getIdentifier(buttonID, "id", getPackageName());
			buttons[i] = (Button)findViewById(resourceID);
			buttons[i].setOnClickListener(this);;
			
			
			
		}
		
		viewMode("end");
		
		startBtn.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View view){
				
				viewMode("start");
				Toast.makeText(MainActivity.this, "���ڰ� �����Ǿ����ϴ�. ���� ���ڸ� ������ ������ �����ּ���",Toast.LENGTH_SHORT).show();
				Random random = new Random();
				randomNumber = random.nextInt(100)+1;
				
				
				
			}
			
		});
		
		answerBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view){
				count++;
				
				
				int inputNumber = Integer.parseInt(requestText.getText().toString());
		
			
				if(inputNumber > randomNumber){
				
					max = inputNumber;
					
					mDriver.setVib(1);
					
				
					
					try{
						Thread.sleep(300);
						
					}catch(InterruptedException e){
						e.printStackTrace();
					}
					mDriver.setVib(0);
					
					responseText.setText(count + " ��°"+min+"~"+max);
				}
			
				else if (inputNumber < randomNumber){
				
					min = inputNumber;
				
					mDriver.setVib(1);
				
					try{
						Thread.sleep(300);
					
					}catch(InterruptedException e){
						e.printStackTrace();
					}
					
					mDriver.setVib(0);
					
					responseText.setText(count + " ��°"+min+"~"+max);
				}
				else if(inputNumber == randomNumber){
					
					
					direction =1;
					mSegThread = new ReceiveThread();
					mSegThread.start();	
					
					try{
						Thread.sleep(3000);
					
					}catch(InterruptedException e){
						e.printStackTrace();
					}
					
					Toast.makeText(MainActivity.this, "�����Դϴ�.",Toast.LENGTH_SHORT).show();
					
					direction =0;
					mSegThread = new ReceiveThread();
					mSegThread.start();	
				
				viewMode("end");
				
				reset();
			}
			
			requestText.setText("");
			
			answer = "";
			}
		});

	}
	@Override
	public void onClick(View view) {
		
		int id = view.getId();
		
		if(checkLength(answer)){
			
			if(id == R.id.btn0){
				answer = answer + "0";
				display();
				
			}else if (id == R.id.btn1){
				answer = answer +"1";
				display();
			}else if (id == R.id.btn2){
				answer = answer +"2";
				display();
			}
			else if (id == R.id.btn3){
				answer = answer +"3";
				display();
			}
			else if (id == R.id.btn4){
				answer = answer +"4";
				display();
			}
			else if (id == R.id.btn5){
				answer = answer +"5";
				display();
			}
			else if (id == R.id.btn6){
				answer = answer +"6";
				display();
			}
			else if (id == R.id.btn7){
				answer = answer +"7";
				display();
			}
			else if (id == R.id.btn8){
				answer = answer +"8";
				display();
			}
			else if (id == R.id.btn9){
				answer = answer +"9";
				display();
			}	
		}
	}
	
	public void viewMode(String type){
		
		//���ӽ���
        if(type.equals("start")){
        	
            startBtn.setEnabled(false); //���۹�ư ��Ȱ��ȭ
            answerBtn.setEnabled(true); //�����ư Ȱ��ȭ
        }
        //���ӿϷ�
        else{
            
            startBtn.setEnabled(true); //���۹�ư Ȱ��ȭ
            answerBtn.setEnabled(false); //�����ư ��Ȱ��ȭ
        }
		
	}
	
	public void reset(){
		
		min = 1;
		max= 100;
		count = 0;
		responseText.setText("");
	}
	
	public void display(){
		requestText.setText(answer);
	}
	
	
	public boolean checkLength(String number){
		boolean result = true;
		
		if(number.length() == 2) {
			
			Toast.makeText(this, "�Է� �Ұ�", Toast.LENGTH_SHORT).show();
			result = false;
		}else{
			result = true;
		}
		return result;
	}
	
	private class ReceiveThread extends Thread{
		public void run(){
			super.run();
			while (mThreadRun){
				mDriver.motor_set(direction);
				
			}
		}
		
	}
	protected void onPause(){
		mDriver.close();
		super.onPause();
	}
	
	protected void onResume(){
		
		if(mDriver.open()<0){
			Toast.makeText(MainActivity.this, "Driver Open Failed", Toast.LENGTH_SHORT).show();
		}
		super.onResume();
	}
}


