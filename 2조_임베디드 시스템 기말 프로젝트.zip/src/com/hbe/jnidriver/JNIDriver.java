
package com.hbe.jnidriver;

public class JNIDriver {
	
	private boolean mConnectFlag;
	int vib_control = 162;
	int step_control[]={208,209,210,211};
	
	

	static {
		System.loadLibrary("JNIDriver");
	}
	private native int gpioexport(int gpio);
	private native int gpiosetdir(int gpio);
	private native int gpiosetval(int gpio,int val);
	private native int gpiounexport(int gpio);
	private native static int gpiogomotor();
	private native static int gpiostopmotor();
	
	
	public JNIDriver(){
		mConnectFlag = false;
	}        
	
	public int open(){
		int i=0;
		
		//����
		if (gpioexport(vib_control) != 0)
			return -1;
		if (gpiosetdir(vib_control) != 0)
			return -1;	 
		
		//����
		if(mConnectFlag) return -1;
		for(i=0;i<4;i++){
			gpioexport(step_control[i]);
			gpiosetdir(step_control[i]);
		}
		mConnectFlag = true;
		
		
		
		
		return 0;
		
		
		
	}
	
	public void close(){
		
		int i=0;
		if(!mConnectFlag) return;
		mConnectFlag = false;
		gpiounexport(vib_control);

		
		for(i=0;i<8;i++){
			gpiounexport(step_control[i]);
		}
		
		
	}
	
	protected void finalize() throws Throwable{
		close();
		super.finalize();
	}
	
	public void setVib(int val){ 
		gpiosetval(vib_control,val);
	}
	public int write(int gpio, int val) {
		return gpiosetval(gpio, val);
	}

	
	public void motor_set(int direction){
		if(!mConnectFlag) return;
		
		if(direction == 1){
			gpiogomotor();
		}
		else if(direction == 0)
		{
			gpiostopmotor();
		}
		
	}
	
	
}
